# 000014 Vetcases

## Reports of notifiable diseases reported for Apis mellifera

This dataset contains data from various sources on the outbreak of notifiable diseases reported for honey bees (*Apis mellifera*) in Belgium and Austria from 2000 to 2022.

### Licence

See Licence.md or table-uid.Licence.md for information about licencing. Note, some tables might use separate licencing then the rest of the database.

This file was downloaded from [EU Pollinator Hub Dataset discovery hub](https://app.pollinatorhub.eu/dataset-discovery/VTCSS14.0.0)

This file was automatically generated on 05.02.2025 by the [EU Pollinator Hub](https://pollinatorhub.eu).

