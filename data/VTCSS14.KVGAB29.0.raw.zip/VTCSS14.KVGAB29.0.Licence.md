# KVG-BMSGPK


===Translated version (English) 2023-10-11===

© Federal Ministry of Social Affairs, Health, Care and Consumer Protection (BMSGPK). The contributions published on this website are protected by copyright. All rights are reserved. Reproduction for non-commercial purposes is permitted provided the source is acknowledged (quote: BMSGPK). For commercial use, permission is required. Separate permission must also be obtained for the use of the BMSGPK logo.
_____________________________________________________________________________
===Original version (German) 2023-10-11===

© Bundesministerium für Soziales, Gesundheit, Pflege und Konsumentenschutz (BMSGPK). Die auf dieser Website veröffentlichten Beiträge sind urheberrechtlich geschützt. Alle Rechte bleiben vorbehalten. Die Wiedergabe für nicht kommerzielle Zwecke ist mit Quellenangabe gestattet (Quelle: BMSGPK). Für die kommerzielle Verwendung bedarf es einer Genehmigung. Für die Nutzung des Logos des BMSGPK muss ebenfalls eine gesonderte Genehmigung eingeholt werden.


[More about the licence](https://www.verbrauchergesundheit.gv.at/service/impressum.html)

[Legal information](https://www.verbrauchergesundheit.gv.at/service/impressum.html)